# sfax

`sfax` is a small package manager for Termux. It reads a JSON package index over HTTPS, resolves package dependencies, downloads `.sfx` archives, checks their manifests and optional SHA-256 digests, then runs package hooks with Bash.

## Build

Use a JDK 11 or newer on the build machine:

```sh
./mvnw -B package
```

The standalone application is created at `target/sfax-1.0-jar-with-dependencies.jar`.

## Install the CLI in Termux

Build the JAR, then run:

```sh
bash install.sh
```

The installer copies the JAR under `$PREFIX/lib/sfax` and creates `$PREFIX/bin/sfax`. It requires Java to be installed in Termux.

## Commands

```text
sfax list
sfax search <query>
sfax info <package>
sfax install <package>
sfax help
```

By default, sfax reads `https://project0earth0not0official0account.github.io/sfax/arm64/packages.json`. Set `SFAX_REPO_URL` to point to another HTTPS `packages.json` index. The index is a JSON array of package manifests:

```json
[
  {
    "name": "hello-termux",
    "version": "1.0.0",
    "architecture": "aarch64",
    "dependencies": [],
    "description": "Example package",
    "url": "hello-termux-1.0.0-termux.sfx",
    "sha256": "optional-64-character-hex-digest"
  }
]
```

An archive is a ZIP file with the `.sfx` extension. It must contain `manifest.json` and `install.sh`; `preinstall.sh`, `postinstall.sh`, and `data/` are optional. Each hook runs with the package directory as its working directory and the extracted `data/` path as its first argument. Hooks should install files under `$PREFIX` and use `pkg` for Termux dependencies. Packages are shell code, so install only from repositories you trust.

The version marker is stored in `$PREFIX/var/lib/sfax/installed`. A matching installed version is skipped; a newer repository version is installed when requested.
