package sfax.cli;

import sfax.core.PackageManager;
import sfax.core.RepoManager;
import sfax.models.PackageManifest;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public final class Main {
    private Main() {}

    public static void main(String[] args) {
        try {
            run(args);
        } catch (Exception e) {
            System.err.println("sfax: " + e.getMessage());
            System.exit(1);
        }
    }

    private static void run(String[] args) throws Exception {
        if (args.length == 0 || "help".equals(args[0]) || "--help".equals(args[0]) || "-h".equals(args[0])) {
            printHelp();
            return;
        }

        switch (args[0]) {
            case "install":
                requireArgument(args, "install <package|./file.sfx>");
                String target = args[1];
                if (target.endsWith(".sfx") || target.startsWith("./") || target.startsWith("../")
                        || Files.isRegularFile(Paths.get(target))) {
                    PackageManager.installLocal(target);
                } else {
                    PackageManager.install(target);
                }
                break;
            case "list":
            case "search":
                String query = args.length > 1 ? args[1] : "";
                List<PackageManifest> packages = new RepoManager().listPackages(query);
                if (packages.isEmpty()) {
                    System.out.println("No packages found.");
                } else {
                    for (PackageManifest pkg : packages) {
                        System.out.printf("%-24s %-12s %s%n", pkg.getName(), pkg.getVersion(), safe(pkg.getDescription()));
                    }
                }
                break;
            case "info":
                requireArgument(args, "info <package>");
                PackageManifest manifest = new RepoManager().getPackage(args[1]);
                if (manifest == null) throw new IllegalArgumentException("Package not found: " + args[1]);
                System.out.println("Name:          " + manifest.getName());
                System.out.println("Version:       " + manifest.getVersion());
                System.out.println("Architecture:  " + safe(manifest.getArchitecture()));
                System.out.println("Description:   " + safe(manifest.getDescription()));
                System.out.println("Dependencies:  " + String.join(", ", manifest.getDependencies()));
                break;
            default:
                throw new IllegalArgumentException("Unknown command: " + args[0] + " (run 'sfax help')");
        }
    }

    private static void requireArgument(String[] args, String usage) {
        if (args.length < 2 || args[1].trim().isEmpty()) throw new IllegalArgumentException("Usage: sfax " + usage);
    }

    private static String safe(String value) { return value == null ? "" : value; }

    private static void printHelp() {
        System.out.println("sfax - package manager for Termux");
        System.out.println("Usage: sfax <command> [arguments]");
        System.out.println("Commands:");
        System.out.println("  install <name|file.sfx>  Install from the repository or a local archive");
        System.out.println("  list            List packages in the configured repository");
        System.out.println("  search <query>  Search package names and descriptions");
        System.out.println("  info <name>     Show package details");
        System.out.println("  help            Show this help");
        System.out.println();
        System.out.println("Set SFAX_REPO_URL to use a different repository index URL.");
    }
}
