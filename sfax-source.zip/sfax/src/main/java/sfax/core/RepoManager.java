package sfax.core;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import sfax.models.PackageManifest;

import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class RepoManager {
    public static final String DEFAULT_INDEX_URL =
            "https://project0earth0not0official0account.github.io/sfax/repo/arm64/packages.json";
    private static final int CONNECT_TIMEOUT_MS = 10_000;
    private static final int READ_TIMEOUT_MS = 30_000;
    private static final Gson GSON = new Gson();

    private final URL indexUrl;
    private List<PackageManifest> packageCache;

    public RepoManager() throws IOException {
        String configured = System.getenv("SFAX_REPO_URL");
        this.indexUrl = new URL(configured == null || configured.trim().isEmpty()
                ? DEFAULT_INDEX_URL : configured.trim());
        if (!"https".equalsIgnoreCase(indexUrl.getProtocol())) {
            throw new IOException("Repository index must use HTTPS");
        }
    }

    public List<PackageManifest> listPackages(String query) throws IOException {
        if (packageCache == null) {
            Type listType = new TypeToken<List<PackageManifest>>() {}.getType();
            HttpURLConnection connection = open(indexUrl);
            try {
                try (InputStreamReader reader = new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8)) {
                    packageCache = GSON.fromJson(reader, listType);
                } catch (JsonParseException e) {
                    throw new IOException("Repository index is not a valid package list", e);
                }
            } finally {
                connection.disconnect();
            }
            if (packageCache == null) packageCache = Collections.emptyList();
        }

        String needle = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<PackageManifest> results = new ArrayList<>();
        for (PackageManifest pkg : packageCache) {
            if (pkg == null || pkg.getName() == null) continue;
            String text = (pkg.getName() + " " + value(pkg.getDescription())).toLowerCase(Locale.ROOT);
            if (needle.isEmpty() || text.contains(needle)) results.add(pkg);
        }
        return results;
    }

    public PackageManifest getPackage(String name) throws IOException {
        for (PackageManifest pkg : listPackages("")) {
            if (pkg.getName().equals(name)) return pkg;
        }
        return null;
    }

    public URL getArchiveUrl(PackageManifest manifest) throws IOException {
        String path = manifest.getUrl();
        if (path == null || path.trim().isEmpty()) {
            path = manifest.getName() + "-" + manifest.getVersion() + "-termux.sfx";
        }
        URL result = new URL(indexUrl, path);
        if (!"https".equalsIgnoreCase(result.getProtocol())) {
            throw new IOException("Package archive URL must use HTTPS");
        }
        return result;
    }

    private static HttpURLConnection open(URL url) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setRequestProperty("User-Agent", "sfax-termux/1.0");
        int status = connection.getResponseCode();
        if (status < 200 || status >= 300) {
            connection.disconnect();
            throw new IOException("Repository returned HTTP " + status + " for " + url);
        }
        if (!"https".equalsIgnoreCase(connection.getURL().getProtocol())) {
            connection.disconnect();
            throw new IOException("Repository redirected to a non-HTTPS URL");
        }
        return connection;
    }

    private static String value(String s) { return s == null ? "" : s; }
}
