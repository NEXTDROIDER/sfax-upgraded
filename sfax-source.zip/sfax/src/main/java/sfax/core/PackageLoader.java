package sfax.core;

import com.google.gson.Gson;
import sfax.models.PackageManifest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public final class PackageLoader {
    private static final Gson GSON = new Gson();

    private PackageLoader() {}

    public static PackageManifest loadManifest(Path archive) throws IOException {
        try (ZipFile zip = new ZipFile(archive.toFile())) {
            ZipEntry entry = zip.getEntry("manifest.json");
            if (entry == null || entry.isDirectory()) throw new IOException("Package has no manifest.json");
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                    zip.getInputStream(entry), StandardCharsets.UTF_8))) {
                PackageManifest manifest = GSON.fromJson(reader, PackageManifest.class);
                if (manifest == null) throw new IOException("Package manifest is empty");
                try {
                    manifest.validate();
                } catch (IllegalArgumentException e) {
                    throw new IOException(e.getMessage(), e);
                }
                if (zip.getEntry("install.sh") == null) throw new IOException("Package has no install.sh");
                return manifest;
            }
        }
    }

    public static void extractPackage(Path archive, Path destination) throws IOException {
        Files.createDirectories(destination);
        Path root = destination.toRealPath();
        try (ZipFile zip = new ZipFile(archive.toFile())) {
            java.util.Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                Path target = root.resolve(entry.getName()).normalize();
                if (!target.startsWith(root)) throw new IOException("Unsafe path in package archive: " + entry.getName());
                if (entry.isDirectory()) {
                    Files.createDirectories(target);
                    continue;
                }
                Files.createDirectories(target.getParent());
                try (InputStream input = zip.getInputStream(entry);
                     OutputStream output = Files.newOutputStream(target)) {
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                }
            }
        }
    }
}
