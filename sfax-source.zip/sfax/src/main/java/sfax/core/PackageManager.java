package sfax.core;

import sfax.models.PackageManifest;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class PackageManager {
    private static final int CONNECT_TIMEOUT_MS = 15_000;
    private static final int READ_TIMEOUT_MS = 120_000;

    private PackageManager() {}

    public static void install(String packageName) throws IOException {
        if (!packageName.matches("[a-z0-9][a-z0-9+._-]{0,63}")) {
            throw new IllegalArgumentException("Invalid package name: " + packageName);
        }
        TermuxUtils.requireTermux();
        RepoManager repository = new RepoManager();
        installRecursive(packageName, repository, new HashSet<>(), new HashSet<>());
    }

    public static void installLocal(String archivePath) throws IOException {
        TermuxUtils.requireTermux();
        Path archive = Paths.get(archivePath).toRealPath();
        if (!Files.isRegularFile(archive) || !archive.getFileName().toString().endsWith(".sfx")) {
            throw new IOException("Local package must be an existing .sfx file: " + archivePath);
        }

        PackageManifest manifest = PackageLoader.loadManifest(archive);
        TermuxUtils.checkArchitecture(manifest.getArchitecture());
        String[] dependencies = manifest.getDependencies();
        if (dependencies.length > 0) {
            RepoManager repository = new RepoManager();
            Set<String> visiting = new HashSet<>();
            Set<String> completed = new HashSet<>();
            visiting.add(manifest.getName());
            for (String dependency : dependencies) {
                installRecursive(dependency, repository, visiting, completed);
            }
        }

        System.out.println("[*] Installing local package " + manifest.getName() + " " + manifest.getVersion() + "...");
        Path work = Files.createTempDirectory(TermuxUtils.getTempPath(), "sfax-");
        try {
            Path extracted = work.resolve("package");
            PackageLoader.extractPackage(archive, extracted);
            Files.createDirectories(extracted.resolve("data"));
            runHook(extracted, "preinstall.sh");
            runHook(extracted, "install.sh");
            runHook(extracted, "postinstall.sh");
            markInstalled(manifest);
            System.out.println("[+] Installed " + manifest.getName() + " " + manifest.getVersion());
        } finally {
            deleteTree(work);
        }
    }

    private static void installRecursive(String name, RepoManager repository,
                                         Set<String> visiting, Set<String> completed) throws IOException {
        if (completed.contains(name)) return;
        if (!visiting.add(name)) throw new IOException("Dependency cycle detected at package " + name);

        PackageManifest entry = repository.getPackage(name);
        if (entry == null) throw new IOException("Package not found in repository: " + name);
        entry.validate();
        if (isInstalled(entry)) {
            completed.add(name);
            visiting.remove(name);
            return;
        }
        for (String dependency : entry.getDependencies()) {
            installRecursive(dependency, repository, visiting, completed);
        }

        System.out.println("[*] Installing " + entry.getName() + " " + entry.getVersion() + "...");
        Path work = Files.createTempDirectory(TermuxUtils.getTempPath(), "sfax-");
        try {
            Path archive = work.resolve("package.sfx");
            download(repository.getArchiveUrl(entry), archive);
            PackageManifest actual = PackageLoader.loadManifest(archive);
            if (!entry.getName().equals(actual.getName()) || !entry.getVersion().equals(actual.getVersion())) {
                throw new IOException("Downloaded package manifest does not match repository index");
            }
            if (!entry.getArchitecture().equalsIgnoreCase(actual.getArchitecture())
                    || !java.util.Arrays.equals(entry.getDependencies(), actual.getDependencies())) {
                throw new IOException("Package metadata does not match repository index for " + entry.getName());
            }
            if (entry.getSha256() != null && !entry.getSha256().trim().isEmpty()
                    && !entry.getSha256().equalsIgnoreCase(sha256(archive))) {
                throw new IOException("SHA-256 mismatch for " + entry.getName());
            }
            TermuxUtils.checkArchitecture(actual.getArchitecture());

            Path extracted = work.resolve("package");
            PackageLoader.extractPackage(archive, extracted);
            Files.createDirectories(extracted.resolve("data"));
            runHook(extracted, "preinstall.sh");
            runHook(extracted, "install.sh");
            runHook(extracted, "postinstall.sh");
            markInstalled(actual);
            completed.add(name);
            System.out.println("[+] Installed " + actual.getName() + " " + actual.getVersion());
        } finally {
            deleteTree(work);
            visiting.remove(name);
        }
    }

    private static void runHook(Path packageDir, String scriptName) throws IOException {
        Path script = packageDir.resolve(scriptName);
        if (!Files.isRegularFile(script)) {
            if ("install.sh".equals(scriptName)) throw new IOException("Package is missing install.sh");
            return;
        }
        Process process = new ProcessBuilder("bash", script.toString(), packageDir.resolve("data").toString())
                .directory(packageDir.toFile())
                .inheritIO()
                .start();
        try {
            int status = process.waitFor();
            if (status != 0) throw new IOException(scriptName + " failed with exit code " + status);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted while running " + scriptName, e);
        }
    }

    private static void download(URL url, Path destination) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("User-Agent", "sfax-termux/1.0");
        try {
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new IOException("Download failed with HTTP " + status + ": " + url);
            if (!"https".equalsIgnoreCase(connection.getURL().getProtocol())) {
                throw new IOException("Package download redirected to a non-HTTPS URL");
            }
            try (InputStream input = connection.getInputStream(); OutputStream output = Files.newOutputStream(destination)) {
                byte[] buffer = new byte[16 * 1024];
                int count;
                while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            }
        } finally {
            connection.disconnect();
        }
    }

    private static String sha256(Path file) throws IOException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (InputStream input = Files.newInputStream(file)) {
                byte[] buffer = new byte[16 * 1024];
                int count;
                while ((count = input.read(buffer)) != -1) digest.update(buffer, 0, count);
            }
            StringBuilder result = new StringBuilder();
            for (byte b : digest.digest()) result.append(String.format(Locale.ROOT, "%02x", b & 0xff));
            return result.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is unavailable", e);
        }
    }

    private static boolean isInstalled(PackageManifest manifest) throws IOException {
        Path marker = TermuxUtils.getStatePath().resolve(manifest.getName() + ".version");
        return Files.isRegularFile(marker)
                && new String(Files.readAllBytes(marker), java.nio.charset.StandardCharsets.UTF_8).trim()
                .equals(manifest.getVersion());
    }

    private static void markInstalled(PackageManifest manifest) throws IOException {
        Path marker = TermuxUtils.getStatePath().resolve(manifest.getName() + ".version");
        Files.write(marker, (manifest.getVersion() + "\n").getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    private static void deleteTree(Path root) throws IOException {
        if (!Files.exists(root)) return;
        try (java.util.stream.Stream<Path> paths = Files.walk(root)) {
            for (Path path : (Iterable<Path>) paths.sorted(java.util.Comparator.reverseOrder())::iterator) {
                Files.deleteIfExists(path);
            }
        }
    }
}
