package sfax.core;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Locale;

public final class TermuxUtils {
    private TermuxUtils() {}

    public static Path getPrefix() throws IOException {
        String prefix = System.getenv("PREFIX");
        if (prefix == null || prefix.trim().isEmpty()) throw new IOException("PREFIX is not set; run sfax inside Termux");
        Path path = Paths.get(prefix).toAbsolutePath().normalize();
        if (!Files.isDirectory(path)) throw new IOException("Termux prefix does not exist: " + path);
        return path;
    }

    public static void requireTermux() throws IOException {
        getPrefix();
    }

    public static Path getTempPath() throws IOException {
        Path temp = getPrefix().resolve("tmp");
        Files.createDirectories(temp);
        return temp;
    }

    public static Path getStatePath() throws IOException {
        Path state = getPrefix().resolve("var/lib/sfax/installed");
        Files.createDirectories(state);
        return state;
    }

    public static void checkArchitecture(String packageArchitecture) throws IOException {
        if (packageArchitecture == null || packageArchitecture.trim().isEmpty()) {
            throw new IOException("Package manifest has no architecture");
        }
        String target = packageArchitecture.toLowerCase(Locale.ROOT);
        if ("all".equals(target) || "termux".equals(target)) return;
        String host = System.getProperty("os.arch", "").toLowerCase(Locale.ROOT);
        boolean hostArm64 = "aarch64".equals(host) || "arm64".equals(host) || "arm64-v8a".equals(host);
        boolean packageArm64 = "aarch64".equals(target) || "arm64".equals(target) || "arm64-v8a".equals(target);
        if (!(hostArm64 && packageArm64) && !target.equals(host)) {
            throw new IOException("Package architecture " + packageArchitecture + " is not compatible with " + host);
        }
    }
}
