package sfax.models;

import java.util.Arrays;

public final class PackageManifest {
    private String name;
    private String version;
    private String[] dependencies = new String[0];
    private String architecture = "all";
    private String description = "";
    private String url;
    private String sha256;

    public String getName() { return name; }
    public String getVersion() { return version; }
    public String[] getDependencies() { return dependencies == null ? new String[0] : dependencies; }
    public String getArchitecture() { return architecture; }
    public String getDescription() { return description; }
    public String getUrl() { return url; }
    public String getSha256() { return sha256; }

    public void validate() {
        if (name == null || !name.matches("[a-z0-9][a-z0-9+._-]{0,63}")) {
            throw new IllegalArgumentException("Invalid package name: " + name);
        }
        if (version == null || version.trim().isEmpty() || version.contains("/") || version.contains("\\")) {
            throw new IllegalArgumentException("Invalid version for package " + name);
        }
        if (architecture == null || architecture.trim().isEmpty()) {
            throw new IllegalArgumentException("Missing architecture for package " + name);
        }
        if (sha256 != null && !sha256.matches("(?i)[a-f0-9]{64}")) {
            throw new IllegalArgumentException("Invalid SHA-256 checksum for package " + name);
        }
        for (String dependency : getDependencies()) {
            if (dependency == null || !dependency.matches("[a-z0-9][a-z0-9+._-]{0,63}")) {
                throw new IllegalArgumentException("Invalid dependency in package " + name + ": " + dependency);
            }
        }
    }

    @Override
    public String toString() {
        return name + " " + version + " (" + architecture + ") " + Arrays.toString(getDependencies());
    }
}
